import Darwin

// 1. Task 1 — Optionals
var name : String? = "Ahmed"
name = nil

if name == nil {print ("There is a name")}

if name != nil

{ print ("there is a name") }



// Task 2 loops
let names = [ "ali" , "ahmed" , "mohmmed" , "khaled" , "saud" ]

for ahmed in names { print(ahmed) }




// Task 3Reuse
func ghjkl (price:Double, dis:Double) -> Double {
    return price - (price * dis)
    
}
print("100-(100 * 0,5")

print("100-(100 * 0,25")




// Task 4 Conditionals
var GAP = 70
if (GAP > 3) {
    print(nice)
}

else if (GAP < 3){
    print("not nice")
}

else if (GAP == 3){
    print("nice and not nice")
}




//5 Task Conditionals

var bonus = 10000
if (bonus > 10000){
    print("you will travel to Paris and London")
}
if (bonus > 5000 && bonus < 9999){
    print("you will travel to Tokyo")
}

if (bonus > 1000 && bonus < 4999){
    print("you will travel to Bangkok")
}
if (bonus < 1000 ){
    print("you just stay home")
}
